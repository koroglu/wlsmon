package acs.oracle.com;

import java.util.Calendar;
import java.util.Random;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.apache.commons.lang.math.RandomUtils;

/**
 * Message-Driven Bean implementation class for: ACSConsumer
 */
@MessageDriven(
		activationConfig = { 
				@ActivationConfigProperty(propertyName = "destination", propertyValue = "jms/acsQueue"), 
				@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
				@ActivationConfigProperty(propertyName = "MaxPoolSize",propertyValue = "50"),
				@ActivationConfigProperty(propertyName = "MinPoolSize",propertyValue = "50")
		}, 
		mappedName = "jms/acsQueue",name = "ACSConsumer")
public class ACSConsumer implements MessageListener {

    /**
     * Default constructor. 
     */
    public ACSConsumer() {
        // TODO Auto-generated constructor stub
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    public void onMessage(Message message) {
    	
    	try {
    		
            Random rand = new Random();
            int rand_int1 = rand.nextInt(100);

			Thread.currentThread().sleep(rand_int1*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	try {
			System.out.println("" + message.getJMSMessageID() +" " + Calendar.getInstance().getTime().toGMTString());
		} catch (JMSException e) {
			e.printStackTrace();
		}
        
    }

}
