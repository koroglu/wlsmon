import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

@MessageDriven(mappedName = "jms/TelauraGenericJMSQ")
public class ProcessEJBBean implements MessageListener {
  public void onMessage(Message message) {
    try {
      ObjectMessage objectMessage = (ObjectMessage)message;
      URL url = new URL("");
      HttpURLConnection urlCon = (HttpURLConnection)url.openConnection();
      urlCon.setDoOutput(true);
      urlCon.setDoInput(true);
      urlCon.setRequestMethod("POST");
      ObjectOutputStream out = new ObjectOutputStream(urlCon.getOutputStream());
      //out.writeObject(.getApiRequestObject());
      out.close();
      urlCon.getResponseCode();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}
