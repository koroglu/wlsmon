package view;

import java.io.IOException;
import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class produce
 */
@WebServlet("/produce")
public class produce extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public final static String JNDI_FACTORY = "weblogic.jndi.WLInitialContextFactory";

	private static InitialContext initialContext = null;
	private static QueueConnectionFactory queueConnectionFactory = null;
	private static QueueConnection queueConnection = null;
	private static QueueSession queueSession = null;
	private static Queue queue = null;
	private static QueueSender queueSender = null;
	private static TextMessage textMessage = null;
	private static final String CONNECTIONFACTORY_NAME = "weblogic.jms.ConnectionFactory";
	private static final String QUEUE_NAME = "jms/acsQueue";

	private static InitialContext getInitialContext(String url) throws NamingException {
		Hashtable env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
		env.put(Context.PROVIDER_URL, url);
		return new InitialContext(env);
	}

	public produce() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void sendMessageToDestination(String messageText) {
		// create InitialContext
		Hashtable properties = new Hashtable();
		properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
		try {
			initialContext = new InitialContext(properties);
			// create QueueConnectionFactory
			queueConnectionFactory = (QueueConnectionFactory) initialContext.lookup(CONNECTIONFACTORY_NAME);

			// create QueueConnection
			queueConnection = queueConnectionFactory.createQueueConnection();

			// create QueueSession
			queueSession = queueConnection.createQueueSession(false, 0);

			// lookup Queue
			queue = (Queue) initialContext.lookup(QUEUE_NAME);

			// create QueueSender
			queueSender = queueSession.createSender(queue);

			// create TextMessage
			textMessage = queueSession.createTextMessage();

			textMessage.setText(messageText);

			// send message
			queueSender.send(textMessage);

			System.out.println("Message sent.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		sendMessageToDestination(request.getParameter("message"));

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
