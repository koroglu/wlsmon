# Accessories

## Useful SCSS shortcuts for UI design

* Gradients
* Patterns
* Color
* Icons
* Font embedding