package model;

public class Composite {
	private String compositeName;
	private String versionNumber;	
	
	public String getCompositeName() {
		return compositeName;
	}
	public void setCompositeName(String compositeName) {
		this.compositeName = compositeName;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	
	public Composite() {
	}	
}
