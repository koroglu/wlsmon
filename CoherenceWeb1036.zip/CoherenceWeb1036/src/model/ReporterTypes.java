package model;

import java.util.ArrayList;
import java.util.List;

public class ReporterTypes {
	private int id;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReporterType() {
		return reporterType;
	}

	public void setReporterType(String reporterType) {
		this.reporterType = reporterType;
	}

	public String getReporterColumns() {
		return reporterColumns;
	}

	public void setReporterColumns(String reporterColumns) {
		this.reporterColumns = reporterColumns;
	}

	private String reporterType;
	private String reporterColumns;
	public static List<ReporterTypes>  lstReporterTypes= new ArrayList();
	
	public ReporterTypes(int id, String reporterType, String reporterColumns) {
		super();
		this.id = id;
		this.reporterType = reporterType;
		this.reporterColumns = reporterColumns;
	}

	static{
		lstReporterTypes.add(new ReporterTypes(1,"report-cache-effectiveness", "report-cache-effectiveness"));
		lstReporterTypes.add(new ReporterTypes(2,"report-cache-size", "report-cache-size"));
		lstReporterTypes.add(new ReporterTypes(3,"report-jcache-statistics", "report-jcache-statistics"));
		lstReporterTypes.add(new ReporterTypes(4,"report-management", "report-management"));
		lstReporterTypes.add(new ReporterTypes(5,"report-memory-status", "report-memory-status"));
		lstReporterTypes.add(new ReporterTypes(6,"report-network-health", "report-network-health"));
		lstReporterTypes.add(new ReporterTypes(7,"report-network-health-detail", "report-network-health-detail"));
		lstReporterTypes.add(new ReporterTypes(8,"report-node", "report-node"));
		lstReporterTypes.add(new ReporterTypes(9,"report-service", "report-network-health-detail"));
		
	}
	
	
	
	
	
	
}
