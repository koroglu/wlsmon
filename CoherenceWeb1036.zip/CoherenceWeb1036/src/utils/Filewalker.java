package utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Filewalker {
	private List<Map<String,Object>> lstFileNames = new ArrayList();

	public List<Map<String,Object>>  walk(String path, String gname) {
		
		File root = new File(path);
		File[] list = root.listFiles();

		if (list == null)
			return null;

		for (File f : list) {
			if (f.isDirectory()) {
				walk(f.getAbsolutePath(),gname);
			} else {
				if(f.getName().toLowerCase().contains(gname.toLowerCase())) {
					Map<String,Object> m = new HashMap();
					m.put("dsc",f.getName());
					m.put("value",f.getAbsolutePath());
					lstFileNames.add(m);
				}
				
			}
		}
		return lstFileNames;
	}


}
