package utils;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.CacheService;
import com.tangosol.net.Service;

public class ACSCoherenceUtils {
	public static List<String> listCacheNames () {
		Enumeration<?> serviceNames = CacheFactory.getCluster().getServiceNames();
		
		List<String> lstCacheNames = new ArrayList();
		while(serviceNames.hasMoreElements()){
		    String serviceName = (String)serviceNames.nextElement();
		    Service service = null;
		    try{
		        service = CacheFactory.getService(serviceName);
		    }catch(Exception e){
		        continue;
		    }
		    if(service instanceof CacheService){
		        CacheService cacheService = (CacheService)service;
		        Enumeration cacheNames = cacheService.getCacheNames();
		        while(cacheNames.hasMoreElements()){
		            String cacheName = (String)cacheNames.nextElement();
		            System.out.println("<<<" + cacheName);
		            lstCacheNames.add(cacheName);
		        }
		    }
		}
		
		return lstCacheNames;
	}
}
