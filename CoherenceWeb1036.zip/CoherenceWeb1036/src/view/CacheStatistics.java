package view;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.JSONWriter;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.net.cache.LocalCache;
import com.tangosol.net.cache.NearCache;
import com.tangosol.net.cache.SimpleCacheStatistics;

/**
 * Servlet implementation class CacheStatistics
 */
public class CacheStatistics extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CacheStatistics() {
        super();
    }

    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cacheName=request.getParameter("cacheName");
		
	    NamedCache cache=null;
	    JSONObject object = new JSONObject();
	    if (cacheName==null) {
	    	object.put("success",false);
	    	object.put("messsage","cache name is null or does not exitst!!");
	    	response.getWriter().write(object.toString());
	    	return;
	    }
	    
	    cache=CacheFactory.getCache(cacheName);
	    if(cache.isActive()){
	        SimpleCacheStatistics scs = new SimpleCacheStatistics();
	        
	        object.put("success",true);
	        long hits = scs.getCacheHits();
	        double averagePutMilis = scs.getAveragePutMillis();
	        double averageGetMilis = scs.getAverageGetMillis();
	        double hitProbability  = scs.getHitProbability();
	        
	        
	        object.put("totalGetsMilis",scs.getTotalGetsMillis());
	        object.put("hits",hits);
	        object.put("averagePutMilis", averagePutMilis);
	        object.put("averageGetMilis", averageGetMilis);
	        object.put("hitProbability", hitProbability);
	        object.put("getTotalGets", scs.getTotalGets());
	        object.put("getTotalPuts", scs.getTotalPuts());
	        response.getWriter().write(object.toString());
	        if (cache instanceof NearCache) {
	            response.getWriter().write("\nstatistics :" + ((LocalCache)((NearCache)cache).getFrontMap()).getCacheStatistics());
	        }

	        
	        
	    }

	    
	    
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
