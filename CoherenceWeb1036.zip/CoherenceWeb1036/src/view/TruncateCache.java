package view;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

import utils.ACSCoherenceUtils;

/**
 * Servlet implementation class TruncateCache<br>
 * Example : <font color=red>http://localhost:7001/CoherenceWeb/TruncateCache?cacheNamePrefix=ACS</font>
 * <br>Output : <br>
 *  	<ul>
 *  		<li>Cache Name = ACSTestCache has been succesfully truncated</li>
 *			<li>Cache Name = ACSTestCache65 has been succesfully truncated</li>
 *		</ul>
 */
public class TruncateCache extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TruncateCache() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cacheNamePrefix=""+request.getParameter("cacheNamePrefix");
		List<String> lstCacheNames = ACSCoherenceUtils.listCacheNames();
		if(cacheNamePrefix.length()<2) {
			response.getWriter().write("cacheNamePrefix must be defined and minumum has 3 characters...");
			return;
		}
		for (String cacheName: lstCacheNames) {
			if (cacheName.contains(cacheNamePrefix)) {
				NamedCache truncatedCache = CacheFactory.getCache(cacheName);
				truncatedCache.destroy();
				response.getWriter().write("\nCache Name = "+ cacheName + " has been succesfully truncated");
			}
				
		}
		
	}
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
