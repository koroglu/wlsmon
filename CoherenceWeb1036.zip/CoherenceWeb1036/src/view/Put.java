package view;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

import utils.ACSCoherenceUtils;

public class Put extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
    public Put() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String cacheName=request.getParameter("cacheName");
		NamedCache cache = CacheFactory.getCache("TestCache");
		if(null!=cacheName) {
			cache=CacheFactory.getCache(cacheName);
		}
		
		
		if (cache.get("counter") ==null ) {
			cache.put("counter",1);
			cache.put(1,new Date());
		}else {
			cache.put("counter",(Integer)(cache.get("counter"))+1);
			cache.put(cache.get("counter"),new Date());
		
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
