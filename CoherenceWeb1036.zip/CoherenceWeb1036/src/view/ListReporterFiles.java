package view;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import utils.Filewalker;

/**
 * Servlet implementation class ListReporterFiles
 */
public class ListReporterFiles extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListReporterFiles() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Filewalker walker = new Filewalker();
		
		String yearAndMonth = ""+Calendar.getInstance().get(Calendar.YEAR)+String.format("%02d", (Calendar.getInstance().get(Calendar.MONTH)+1));
		List<Map<String, Object>> walk = null;
		System.out.println("USER DIR = "+System.getProperty("user.dir"));
		System.out.println("YEAR  " +yearAndMonth );
		if(request.getParameter("yearAndMonth")!=null ) {
			walk=walker.walk(System.getProperty("user.dir"), request.getParameter("yearAndMonth"));
		}else {
			walk=walker.walk(System.getProperty("user.dir"), yearAndMonth);
		}
		
		
		JSONObject obj = new JSONObject();
		obj.put("list", walk);
		response.getWriter().write(obj.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
