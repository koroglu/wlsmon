package view;

import java.util.Date;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

/**
 * Application Lifecycle Listener implementation class AllianzCoherenceListener
 *
 */
public class AllianzCoherenceListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public AllianzCoherenceListener() {
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent contextEvent)  { 
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent contextEvent)  { 
    	System.out.println("ACS COHRENCE #################################");
		NamedCache cache = CacheFactory.getCache("ACSTestCache");
		cache.put(0, new Date());
		CacheFactory.ensureCluster();
		System.out.println("#################################ACS COHERENCE");
    }
	
}
