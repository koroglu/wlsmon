package view;

import java.io.IOException;
import java.util.Collection;
import java.util.Set;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.openmbean.TabularData;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.Cluster;
import com.tangosol.net.NamedCache;
import com.tangosol.net.management.MBeanHelper;
import java.io.IOException;
import java.util.Collection;
import java.util.Set;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.openmbean.TabularData;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.Cluster;
import com.tangosol.net.NamedCache;
import com.tangosol.net.management.MBeanHelper;


public class MBeanReporter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MBeanReporter() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// enable management before we start/join a cluster
		System.setProperty("tangosol.coherence.management", "all");
		System.setProperty("tangosol.coherence.log.level", "2");
		Cluster cluster = CacheFactory.ensureCluster();
		MBeanServer server = MBeanHelper.findMBeanServer();
		// create caches and add some data
		NamedCache nc1 = CacheFactory.getCache("dist-tim1");
		NamedCache nc2 = CacheFactory.getCache("dist-tim2");
		nc1.put("key1", "value1");
		nc2.put("key1", "value1");
		// get the local member to run the report on
		int nLocalMemberId = cluster.getLocalMember().getId();
		String clusterName=cluster.getClusterName();
		String memberName=cluster.getLocalMember().getMemberName();
		
		String reportType=request.getParameter("reporterType");
		if (reportType==null) reportType="report-cache-size.xml";
		TabularData reportData = null;
		try {
			reportData = (TabularData) server.invoke(
					new ObjectName("Coherence:type=Reporter,cluster="+clusterName+",member="+memberName+",nodeId=" + nLocalMemberId), 
					"runTabularReport", new Object[] { "reports/"+reportType +".xml"}, new String[] { "java.lang.String" });
			if (reportData != null) {
				Set<?> setKeys = reportData.keySet();
				if (setKeys.size() > 0) {
					// loop through each key, which is actually the row of data
					for (Object oKey : setKeys) {
						// get the columns as an array
						Object[] aoColumns = ((Collection<Object>) oKey).toArray();
						for (int i = 0; i < aoColumns.length; i++) {
							String value =null== aoColumns[i] ?"": aoColumns[i].toString();
						//	System.out.print(value + "\t");
							response.getWriter().write(value + "\t");
						}
						response.getWriter().write("\n");
						//	System.out.println();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
