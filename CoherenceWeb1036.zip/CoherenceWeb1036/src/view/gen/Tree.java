package view.gen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import model.Nodes;

/**
 * Servlet implementation class Tree
 */
public class Tree extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Tree() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Nodes> lstNodes = new ArrayList();
		Nodes node = new Nodes("1", "", false, "Statistics", "Statistics", "0");
		lstNodes.add(node);
		node = new Nodes("11", "", true, "Nodes Statistic", "Nodes", "1");
		lstNodes.add(node);
		node = new Nodes("12", "", true, "Network Health", "NetworkHealth", "1");
		lstNodes.add(node);
		node = new Nodes("13", "", true, "Network Detail", "NetworkHealthDetail", "1");
		lstNodes.add(node);
		node = new Nodes("14", "", true, "Memory Status", "Memory", "1");
		lstNodes.add(node);
		node = new Nodes("15", "", true, "Persistence", "Persistence", "1");
		lstNodes.add(node);
		node = new Nodes("16", "", true, "Persistence Details", "PersistenceDetails", "1");
		lstNodes.add(node);
		node = new Nodes("17", "", true, "Cache Usage", "CacheUsage", "1");
		lstNodes.add(node);
		
		node = new Nodes("2", "", false, "Management", "JVM", "0");
		lstNodes.add(node);
		node = new Nodes("21", "", true, "List Caches", "ListCaches", "2");
		lstNodes.add(node);
		node = new Nodes("22", "", true, "Get Test", "GetTest", "2");
		lstNodes.add(node);
		node = new Nodes("23", "", true, "Put Test", "PutTest", "2");
		lstNodes.add(node);
		node = new Nodes("24", "", true, "Truncate Caches", "Truncate Caches", "2");
		lstNodes.add(node);
		node = new Nodes("25", "", true, "Reporter MBean", "Reporter", "2");
		lstNodes.add(node);
		
		

		lstNodes.add(node);
		String id= request.getParameter("id");
		JSONObject json = new JSONObject();
		
		List<Nodes> lstReturn = new ArrayList();
		for(Nodes n:lstNodes) {
			if(n.getParentId().equals(id)) {
				lstReturn.add(n);
			}
		}
		json.put("success",true);
		json.put("data",lstReturn);
		response.getWriter().write(json.toString());

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		doGet(request, response);
	}

}
